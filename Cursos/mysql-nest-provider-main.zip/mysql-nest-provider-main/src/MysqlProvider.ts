import { MysqlConfiguration } from './MysqlConfiguration';
import * as mysql from 'mysql2/promise';
import { apm } from '@ndcmsl/logs-service';
import { getEnv } from '@ndcmsl/shared';

export const MysqlProvider = async (connectionName: string): Promise<mysql.Pool> => {
    const mysqlConfigurations = getEnv().mysql;
    if (connectionName === 'default' && !mysqlConfigurations?.default) {
        console.log(
            '\x1b[36m%s\x1b[0m',
            `Configuration ${connectionName} (Mysql) is not defined (Make sure you dont need it)`,
        );
        return null;
    }
    const configuration: MysqlConfiguration = mysqlConfigurations?.[connectionName] ?? mysqlConfigurations?.default;
    if (!configuration) {
        console.log('\x1b[31m%s\x1b[0m', ` ${connectionName} (Mysql) configuration is not defined`);
        return null;
    }
    const { db, user, password, host, maxConnections, port } = configuration;
    const variablesNeeded = [];
    const defaultMaxConnections = 10;
    if (!host || host.trim() === '') variablesNeeded.push('host');
    if (!db || db.trim() === '') variablesNeeded.push('database');
    if (!user || user.trim() === '') variablesNeeded.push('user');
    if (variablesNeeded.length > 0)
        console.log(`Mysql provider needs ${variablesNeeded.join(', ')} to not be empty or undefined`);
    let pool: mysql.Pool = null;
    try {
        pool = mysql.createPool({
            host,
            user,
            database: db,
            password,
            port: port ?? 3306,
            waitForConnections: true,
            connectionLimit: maxConnections ?? defaultMaxConnections,
            queueLimit: 0,
            dateStrings: false,
        });
        await pool.query('SELECT 1');
        console.log('\x1b[32m%s\x1b[0m', `Connection pool ${connectionName} (Mysql) created`);
    } catch (error) {
        if (getEnv().app.errorLogPrint) console.log(error);
        apm?.captureError(error);
        console.log('\x1b[31m%s\x1b[0m', `Could not create ${connectionName} connection pool (Mysql)`);
    }
    return pool;
};
