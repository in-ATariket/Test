import { apm } from '@ndcmsl/logs-service';
import { getEnv } from '@ndcmsl/shared';
import knex from 'knex';

export type MysqlKnexConfiguration = {
    db: string;
    user: string;
    port?: number;
    password: string;
    useNullAsDefault: boolean;
    host: string;
    maxConnections: number;
    minConnections?: number;
};

export const mysqlKnex = knex({
    client: 'mysql2',
});

export const MysqlKnexProvider = async (connectionName: string) => {
    const configuration: MysqlKnexConfiguration = getEnv().mysql[connectionName] ?? getEnv().mysql.default;
    const { host, db, port, user, password, maxConnections, minConnections, useNullAsDefault } = configuration;
    const knexPool = knex({
        client: 'mysql2',
        connection: {
            host: host,
            port: port ?? 3306,
            user,
            password,
            database: db,
        },
        useNullAsDefault,
        pool: { min: minConnections ?? 1, max: maxConnections ?? 5 },
    });
    try {
        await knexPool.select(1);
        console.log('\x1b[32m%s\x1b[0m', `Connection pool ${connectionName} (MysqlKnex) created`);
    } catch (error) {
        if (getEnv().app.errorLogPrint) console.log(error);
        apm?.captureError(error);
        console.log('\x1b[31m%s\x1b[0m', `Could not create ${connectionName} connection pool (MysqlKnex)`);
        return null;
    }
    return knexPool;
};
