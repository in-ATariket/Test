export type MysqlConfiguration = {
    db: string;
    user: string;
    port?: number;
    password: string;
    host: string;
    maxConnections: number;
    minConnections?: number;
};

export type MysqlRepositoryConfiguration = {
    debug?: boolean;
};
